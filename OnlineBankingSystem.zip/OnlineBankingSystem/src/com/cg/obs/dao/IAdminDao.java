package com.cg.obs.dao;

import java.sql.Date;
import java.util.ArrayList;

import com.cg.obs.bean.Account;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.Transactions;



public interface IAdminDao {

	ArrayList<Transactions> getDailyTransactions(Date date1);

	

	Long saveCustomer(Customer cBean);



	void saveAccount(Account aBean);



	ArrayList<Transactions> getMonthlyTransactions(String month);



	

}
