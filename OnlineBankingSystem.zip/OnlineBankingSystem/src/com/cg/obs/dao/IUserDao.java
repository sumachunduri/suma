package com.cg.obs.dao;

import com.cg.obs.bean.Customer;

public interface IUserDao {

	

	Customer findCustomer(Long id);

	void update(Customer customer);

}
