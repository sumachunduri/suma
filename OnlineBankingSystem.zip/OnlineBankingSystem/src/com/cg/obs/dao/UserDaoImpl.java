package com.cg.obs.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.obs.bean.Customer;
import com.cg.obs.bean.Transactions;


@Repository
public class UserDaoImpl implements IUserDao{
	@PersistenceContext
	EntityManager entityManager;
	
	

	@Override
	public Customer findCustomer(Long id) {
		// TODO Auto-generated method stub
		Customer c=entityManager.find(Customer.class, id);
		return c;
	}

	@Override
	public void update(Customer customer) {
		// TODO Auto-generated method stub
		entityManager.merge(customer);
		
	}

}
