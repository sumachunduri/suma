package com.cg.obs.dao;

import java.sql.Date;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.obs.bean.Account;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.Transactions;


@Repository

public class AdminDaoImpl implements IAdminDao{

	@PersistenceContext
	EntityManager entityManager;
	ArrayList<Transactions> trantList = null;
	@Override
	public ArrayList<Transactions> getDailyTransactions(Date date1) {
		// TODO Auto-generated method stub
		String dailyTranQuery = IQueryMapper.FETCH_TRANSACTIONS_CURRENT_DATE;
		try {
			TypedQuery<Transactions> tq = entityManager.createQuery(dailyTranQuery, Transactions.class);
			tq.setParameter("date1", date1); 
			trantList = (ArrayList<Transactions>) tq.getResultList();
	}catch(Exception e){
		//logger.info(e.getMessage());
		//throw new AirlineException("Due to some technical problems,transaction cannot be initiated");
		e.printStackTrace();
	}
		return trantList;
}
	@Override
	public Long saveCustomer(Customer cBean) {
		// TODO Auto-generated method stub
		entityManager.persist(cBean);
		entityManager.flush();
		Long id=cBean.getAccountID();
		return id;
	}
	@Override
	public void saveAccount(Account aBean) {
		// TODO Auto-generated method stub
		entityManager.persist(aBean);
		entityManager.flush();
		
	}
	@Override
	public ArrayList<Transactions> getMonthlyTransactions(String month) {
		// TODO Auto-generated method stub
		String dailyTranQuery = IQueryMapper.FETCH_TRANSACTIONS_GIVEN_MONTH;
		try {
			TypedQuery<Transactions> tq = entityManager.createQuery(dailyTranQuery, Transactions.class);
			tq.setParameter("month", month);  
			trantList = (ArrayList<Transactions>) tq.getResultList();
	}catch(Exception e){
		//logger.info(e.getMessage());
		//throw new AirlineException("Due to some technical problems,transaction cannot be initiated");
		e.printStackTrace();
	}
		return trantList;
	}
	
}
