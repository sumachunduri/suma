package com.cg.obs.dao;

public interface IQueryMapper {
	public static final String FETCH_TRANSACTIONS_CURRENT_DATE="SELECT t FROM Transactions t WHERE t.date=:date1 " ;
	public static final String FETCH_TRANSACTIONS_GIVEN_MONTH = "SELECT t FROM Transactions t WHERE to_char(t.date,'fmMonth')=:month" ;
	public static final String FETCH_ADDRESS_GIVEN_ACCOUNTID = "SELECT  c.address FROM Customer c WHERE t.accountID:=id ";
	public static final String UPDATE_ADDRESS_GIVEN_ACCOUNTID = "UPDATE ";
}
