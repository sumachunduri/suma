package com.cg.obs.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import com.cg.obs.bean.Customer;
import com.cg.obs.service.IUserService;


@Controller
public class UserController {
Long accountId;
Customer customer;
	@Autowired
	IUserService userService;
	
	@RequestMapping("/userLogin")
	public  String getUserLoginPage(){
		return "OBS_User_Login";
	}
	@RequestMapping(value="/userAccount",method=RequestMethod.POST)
	public String getUserAccountPage(){
		return "OBS_User_AccountLogin";
	}
	@RequestMapping("/userHome")
	public  String getUserHomePage(@RequestParam("id") Long id){
	 accountId=id;
		return "OBS_User_Home";
	}
	@RequestMapping("/change")
	public  String changeAddress(Model m){
		
		customer=userService.findCustomer(accountId);
		String oldAddress=customer.getAddress();
		m.addAttribute("old",oldAddress ); 
		System.out.println(oldAddress);
		return "OBS_User_ChangeAddress";
	} 
	@RequestMapping("/updateAddress")
	public  String updateAddress(@RequestParam("customerAddress") String newAddress, Model m){
		customer.setAddress(newAddress);
		userService.update(customer);
		m.addAttribute("msg", "updated successfully");
		return "success";
	}
}
 