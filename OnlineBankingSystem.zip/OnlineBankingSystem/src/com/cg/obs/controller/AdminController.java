package com.cg.obs.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.obs.bean.Account;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.Transactions;

import com.cg.obs.service.IAdminService;


@Controller

public class AdminController {
	@Autowired 
	IAdminService adminService;
	@RequestMapping("/index")
	public  String getIndexPage(){
		return "OBS_All_Index";
	}

	@RequestMapping("/adminLogin")
	public  String getAdminPage(){
		return "OBS_Admin_Login";
	}

	@RequestMapping("/ValidateAdmin")
	public  String getAdminValidationPage(){
		return "OBS_Admin_Home";
	}
	@RequestMapping("/adminHome")
	public  String getAdminHomePage(){
		return "OBS_Admin_Home";
	}
	@RequestMapping("/AddAccountHolder")
	public  String getAddAccountHolderPage(Model m){ 
		java.sql.Date date=java.sql.Date.valueOf(LocalDate.now());
		m.addAttribute("date", date);
				return "OBS_Admin_AddAccount";
	}
	@RequestMapping("/ProcessAddAccountHolder")
	public  String process(@RequestParam("customerName") String name,@RequestParam("customerAddress") String address,@RequestParam("customerEmail") String email,@RequestParam("customerPancard") String pan,@RequestParam("accountType") String accountType,@RequestParam("accountBalance") Integer balance,@RequestParam("accountOpenDate") Date date,Model m){
		Customer cBean=new Customer();
		cBean.setAddress(address);
		cBean.setCustomerName(name);
		cBean.setEmail(email);
		cBean.setPanCard(pan);
		
		Long id=adminService.saveCustomer(cBean);
		Account aBean=new Account();
		aBean.setAccountId(id);
		aBean.setAccountType(accountType);
		aBean.setOpenDate(date);
		aBean.setAccountBalance(balance);
		adminService.saveAccount(aBean) ;
		
		
		String message="data inserted";
		m.addAttribute("msg", message);
		
		 
		return "OBS_Admin_AddAccount";
	}
	@RequestMapping("/Transactions")
	public  String getTransactionsPage( Model m){
		
		return "OBS_Admin_ViewTran";
	}
	@RequestMapping("/dailyTransaction")
	public  String getdailyTransactionPage( Model m){
		ArrayList<Transactions> list = new ArrayList<Transactions>();
		java.sql.Date date1=java.sql.Date.valueOf(LocalDate.now());
		list=adminService.getDailyTransactions(date1);
		 m.addAttribute("list", list);
		System.out.println(list); 
		return "OBS_Admin_DailyTran";
	}
	
	@RequestMapping("/monthlyTransaction")
	public  String getMonthlyTransactionPage(@RequestParam("month") String month,Model m){
		ArrayList<Transactions> list = new ArrayList<Transactions>();
	
		list=adminService.getMonthlyTransactions(month);
		 m.addAttribute("list", list);
		System.out.println(list); 
		return "OBS_Admin_DailyTran";
	}
	

	
	
	
	

}
