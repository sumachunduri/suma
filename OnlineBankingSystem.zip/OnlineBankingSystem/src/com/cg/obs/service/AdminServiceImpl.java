package com.cg.obs.service;

import java.sql.Date;
import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.obs.bean.Account;
import com.cg.obs.bean.Customer;
import com.cg.obs.bean.Transactions;
import com.cg.obs.dao.IAdminDao;


@Service
@Transactional
public class AdminServiceImpl  implements IAdminService{

	@Autowired
	IAdminDao adminDao;
	@Override
	public ArrayList<Transactions> getDailyTransactions(Date date1) {
		// TODO Auto-generated method stub
		return adminDao.getDailyTransactions(date1);
	}
	@Override
	public Long saveCustomer(Customer cBean) {
		// TODO Auto-generated method stub
		return adminDao.saveCustomer(cBean);
	}
	@Override
	public void saveAccount(Account aBean) {
		// TODO Auto-generated method stub
		adminDao.saveAccount(aBean);
	}
	@Override
	public ArrayList<Transactions> getMonthlyTransactions(String month) {
		// TODO Auto-generated method stub
		return adminDao.getMonthlyTransactions(month);
	}
	

} 
