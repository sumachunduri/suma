package com.cg.obs.service;

import com.cg.obs.bean.Customer;



public interface IUserService {

	


	Customer findCustomer(Long id);

	void update(Customer customer);

}
