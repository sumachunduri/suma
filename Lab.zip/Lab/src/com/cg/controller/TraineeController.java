package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;





import com.cg.entity.Trainee;
import com.cg.service.TraineeService;

@Controller
public class TraineeController {
	Trainee trainee2; 
	Trainee trainee3;
	@Autowired
	private TraineeService  traineeService; 
	@RequestMapping("/index")
	public String getLoginPage(){
		return "login";
	}
	@RequestMapping("/login")
	public String getHomePage(@RequestParam("name") String name,@RequestParam("pass") String pass)
	{
		String target="login";
		if("admin".equals(name) && "admin".equals(pass)){
			target="home";
		}
		return target;
	}
	@RequestMapping("/add")
	public String addTrainee(Model m)
	{
		Trainee trainee=new Trainee();
		m.addAttribute("list",new String[]{"System Associate","Asst Manager","Dy Manager","Manager"});
		m.addAttribute("trainee", trainee);
		return "addtrainee";
	}
	@RequestMapping("/save")
	public String saveTrainee(@ModelAttribute("trainee") Trainee trainee)
	{

			 traineeService.save(trainee);
			 return "home";
	}
	@RequestMapping("/delete")
	public String deleteTrainee(Model m)
	{
		
		
		m.addAttribute("trainee2", new Trainee());
		return "deletetrainee";
	}
	@RequestMapping("/deleted")
	public String deleted(@RequestParam("id") Integer id,Model m)
	{
		 trainee2=traineeService.find(id);
		m.addAttribute("trainee2",trainee2);
			  return "deletetrainee";
	}
	@RequestMapping("/remove")
	public String removeme(@ModelAttribute("trainee2") Trainee trainee2)
	{

			 traineeService.removeTrainee(trainee2);
			 return "home";
	}
	@RequestMapping("/modify")
	public String modifyTrainee(Model m)
	{
		 trainee3=new Trainee();
		m.addAttribute("trainee3", trainee3);
		return "modifytrainee";
	}
	
	@RequestMapping("/retrieve")
	public String retrieveTrainee(Model m)
	{
		Trainee trainee4=new Trainee();
		m.addAttribute("trainee4", trainee4);
		return "retrievetrainee";
	}
	@RequestMapping("/retrieved")
	public String retrievedTrainee(@RequestParam("id") Integer id,Model m)
	{
		Trainee traniee4=traineeService.find(id);
		m.addAttribute("trainee4",traniee4);
		return "retrievetrainee";
	}
	@RequestMapping("/retrieveall")
	public String retrieveAll(Model m)
	{
		List<Trainee>tlist=new ArrayList<Trainee>();
		tlist= traineeService.retrieveall();
		m.addAttribute("list", tlist);
		return "retrieveall";
	}
}
