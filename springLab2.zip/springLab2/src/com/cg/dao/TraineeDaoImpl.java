package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;



import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.entity.Trainee;
@Repository

public class TraineeDaoImpl implements TraineeDao{

	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void save(Trainee trainee) {
		// TODO Auto-generated method stub
		entityManager.persist(trainee);
		//entityManager.flush();
	}

	@Override
	public Trainee find(Integer id) {
		// TODO Auto-generated method stub
		Trainee traniee1 = entityManager.find(Trainee.class, id);
		return traniee1;
	
	}

	@Override
	public void removeTrainee(Trainee trainee2) {
		// TODO Auto-generated method stub
		System.out.println("removing");
		try{
		entityManager.remove(trainee2);
		}catch(Exception e){
			e.printStackTrace();
		}
      
	}

	@Override
	public List<Trainee> retrieveall() {
		// TODO Auto-generated method stub
		TypedQuery<Trainee> query = entityManager.createQuery("SELECT e FROM Trainee e", Trainee.class);
		return query.getResultList(); 
	}

}
