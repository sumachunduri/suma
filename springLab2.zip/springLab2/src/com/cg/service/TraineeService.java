package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.entity.Trainee;

public interface TraineeService {

 public	void save(Trainee trainee);

public Trainee find(Integer id);

public void removeTrainee(Trainee trainee1);

public List<Trainee> retrieveall();

}
