<html>
<head>
<style>
body {
	 background-color:lightblue;

}
</style>
</head>
<body>

<b>Your Orders are </b><br><br>

IPHONE :<?php echo $_GET["phonecount"]; ?><br>
LAPTOP :<?php echo $_GET["lapcount"]; ?><br>
TV :<?php echo $_GET["tvcount"]; ?><br>

</body>
</html>