<html>
<title></title>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Pament Complete</title>
</head>
<body align="center" style="background-color:white">
<?php include "menu.php"; 
$r1=$_POST['iname'];
$r2=$_SESSION['user'];
$r3= date("d/m/Y");
echo $r1;
echo $r2;
echo $r3;
?>

<br><br><br><br><br><br><br><br><br><br>
<h1 align='center' style='color:black'>Thank You For Shopping With Us</h1>
<!--<?php header("Refresh:2; url=Products.php"); ?>-->
</body>
</html>