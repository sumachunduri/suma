<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Register</title>
<style>

/* Full-width input fields */
input[type=text], input[type=password],input[type=number],input[type=email] {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: #f1f1f1;
}

/* Add a background color when the inputs get focus */
input[type=text]:focus, input[type=password]:focus,input[type=number]:focus,input[type=email]:focus {
    background-color: #ddd;
    outline: none;
}

/* Set a style for all buttons */
button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    opacity: 0.9;
}

button:hover {
    opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
    padding: 14px 20px;
    background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  width: 50%;
}

/* Add padding to container elements */
.container {
    padding: 16px;
}



/* Style the horizontal ruler */
hr {
    border: 1px solid #f1f1f1;
    margin-bottom: 25px;
}
 
/* The Close Button (x) */
.close {
    position: absolute;
    right: 35px;
    top: 15px;
    font-size: 40px;
    font-weight: bold;
    color: #f1f1f1;
}

.close:hover,
.close:focus {
    color: #f44336;
    cursor: pointer;
}

/* Clear floats */
.clearfix::after {
    content: "";
    clear: both;
    display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
    .cancelbtn, .signupbtn {
       width: 100%;
    }
}

</style>


</head>
<?php
	if (isset($_POST['signup']))
	{
		require 'connect.php';

		$sql = "SELECT id FROM users where username='".$conn->real_escape_string($_POST['username'])."'";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			echo '<div align="center">Username already taken.</div>';
		} else {
			$sql = "INSERT INTO users (type,first_name,last_name,dob,gender,mobile_no,email_id,username,password,adrs,city,country,zip,registered_time) VALUES ('".$conn->real_escape_string($_POST['type'])."','".$conn->real_escape_string($_POST['Firstname'])."','".$conn->real_escape_string($_POST['Lastname'])."','".$conn->real_escape_string($_POST['dob'])."','".$conn->real_escape_string($_POST['gender'])."','".$conn->real_escape_string($_POST['mobileno'])."','".$conn->real_escape_string($_POST['emailid'])."','".$conn->real_escape_string($_POST['username'])."','".$conn->real_escape_string($_POST['pswd'])."','".$conn->real_escape_string($_POST['addr'])."','".$conn->real_escape_string($_POST['city'])."','".$conn->real_escape_string($_POST['country'])."','".$conn->real_escape_string($_POST['zip'])."','".date("Y-m-d H:i:s")."');";

			if ($conn->query($sql) === TRUE) {
			    echo '<div align="center">User Registered.</div>';
			    header("Refresh:1; url=Login.php");
			} else {
			    echo '<div align="center">Unable to register user.</div>';
			}
		}
		$conn->close();
	}
?>

<center><form action="Register.php" method="post">
 <div class="container">
      <h1>Register</h1>
      <p><font size="4">Please fill in this form to create an account.</font></p>
      <hr>
<label for="type" class="required"><b>Type</b></label><br><br>
      </font><font size="4">
      <input type="radio" name="type" value="user" />User
      <input type="radio" name="type" value="store" />Store<br><br>
<label for="Firstname"><b><font size="4">First Name</font></b></label></font><font size="4">
      <input type="text" placeholder="Enter First Name" name="Firstname" id="Firstname" required validationMessage="Enter First Name">
<label for="Lastname"><b>Last Name</b></label>
      </font><font size="4">
      <input type="text" placeholder="Enter Last Name" name="Lastname" id="Lastname" required validationMessage="Enter Last Name>
<label for="dob"><b>Date Of Birth </b></label> 
	<input type="text" name="dob"  id="dob" pattern="\d{1,2}-\d{1,2}-\d{4}" placeholder="DD-MM-YYY" required validationMessage="Enter date of birth" /> 
<label for="gender" class="required"><b>Gender</b></label><br><br>
      </font><font size="4">
      <input type="radio" name="gender" value="Male" />Male
      <input type="radio" name="gender" value="Female" />Female
      <input type="radio" name="gender" value="Others" />Others<br><br>
<label for="addr"><b>House/Flat/Door No</b></label>
      </font><font size="4">
      <input type="text" placeholder="Enter Door No" name="addr" id="addr" required validationMessage="Enter Door No" />
<label for="city"><b>City</b></label>
      </font><font size="4">
      <input type="text" placeholder="Enter City Name" name="city" id="city" required validationMessage="Enter City Name" />
<label for="country"><b>Country</b></label>
      <input type="text" placeholder="Enter Country Name" name="country" id="country" required validationMessage="Enter Country Name" />
<label for="zip"><b>Pin Code</b></label>
      <input type="number" placeholder="Enter Pin Code" name="zip" id="zip" pattern="\d{6}" required validationMessage="Enter Valid Pin Code" />
<label for="mobileno"><b>Phone Number</b></label>
      <input type="text" placeholder="Enter Phone Number" name="mobileno" id="mobileno" pattern="\d{10}" required validationMessage="Enter Phone No" />
<label for="emailid"><b>Email ID</b></label>
      <input type="email" placeholder="Enter Email ID" name="emailid" id="emailid" required validationMessage="Enter Email ID" />
<label for="username"><b>Username</b></label>
      <input type="text" placeholder="Enter Username" name="username" id="username" required validationMessage="Enter Username" />
<label for="pswd"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="pswd" id="pswd" required validationMessage="Enter Password" />

		</font>
      <div class="clearfix">
        <button type="submit" class="signupbtn" name="signup"><font size="4">Sign Up</font></button>
        <button type="reset" onclick="location.href='login.php'" class="cancelbtn">
		<font size="4">Cancel</font></button>
        </div>  
      </div>
</form></center><br><br><br><br>
<center>
<footer>
<b>All rights reserved. �  2017 Project @ SAU Privacy policy</b>
</footer>
</center>				
</body>
</html>
