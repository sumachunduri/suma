<div>
<img src="img/final.jpg" width="100%" height="200px" / >
</div>

<!DOCTYPE html>
<html>
<head> <title> visit</title>
<link rel="stylesheet" href="buttons.css"
</head>

</html>

<table align="center">
<tr><td>
<nav>
<a href="index.php" class="button">HOME</a>
<a href="About.php" class="button">ABOUT US</a>
<a href="contactus.php" class="button">CONTACT US </a>
<a href="show_cart.php" class="button">CART</a>

<?php
    session_start();
    echo (isset($_SESSION['cus_log']))?'<a href="Logout.php" class="button">LOGOUT</a> <a href="showorderh.php" class="button">Order History</a><a href="storedashboard.php" class="button">Dashboard</a> Welcome, '.$_SESSION['user']:'<a href="Login.php" class="button">LOGIN</a>';

    
    
?>
</nav>
</td>
</tr>
</table>
</form>