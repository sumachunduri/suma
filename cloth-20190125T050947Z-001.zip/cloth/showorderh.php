<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Card Details</title>
<style>


body {
    background-color: white;
}
.button {
    background-color:teal;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	
	
}
 </style>
 </head>
<body style="background-color:#CAD8DC" >

<?php include "menu.php"; 
include("condbh.php");
$u=$_SESSION['user'];

if($u=="admin")
{
$q1 = "select img,name,price,date from payment";
$result1 = mysql_query($q1) or die(mysql_error());
}
if($u!="admin")
{
$q1 = "select img,name,price,date from payment where user='$u'";
$result1 = mysql_query($q1) or die(mysql_error());
}


?>
 <h1 align="center">Your Order History</h1>
 <table border=1 align="center" width="50%">
<tr><td><b>img</b></td>
<td><b>Item Name</b></td>
<td><b>price</b></td>
<td><b>date</b></td>

</tr>
<?php
while( $row1 = mysql_fetch_array($result1))
{


 ?>

	<tr>
	
		<td><?php echo "<img src='img/".$row1['img']."' height='300px' width='300px'/>"; ?></td>
		<td><?php echo $row1['name']; ?></td>
					<td><?php echo $row1['price']; ?></td>
		<td><?php echo $row1['date']; ?></td>

		<!-- <td align="left">
		<input type="text" size="20" style="border: 1px solid #C0C0C0" name="r1[]"></td> -->
	</tr>

	<?php } ?>
		</table>

		<br>
<br>
<br>
<center>
<footer>
<b>All rights reserved.
 �  2017 Project @ SAU
Privacy policy</b>
</footer>
</center>
</body>

 </html>
