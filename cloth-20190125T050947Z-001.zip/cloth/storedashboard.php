<!DOCTYPE html>
<html>
<head> <title> store </title>
<link rel="stylesheet" href="buttons.css"
</head>
<body>
	<header>
		<div class="buttons"> Dashboard </div>
	</header><br /><br />
	<center>
	<a href="add.html"><button class="button"> ADD PRODUCT </button></a>
	<a href="delte.html"><button class="button"> DELETE PRODUCT  </button></a>
	<a href="visit.html"><button class="button"> VISITS </button></a>
	<a href="blocked.html"><button class="button"> BLOCKED ITEMS </button></a>

	</center>
</body>
</html>