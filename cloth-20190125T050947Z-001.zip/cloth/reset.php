<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Reset Password</title>
<body align="center" style="background-color:white">
</head>
<!--<?php
	if (isset($_POST['submit']))
	{
		require 'connect.php';

		$sql = "SELECT id FROM users where username='".$conn->real_escape_string($_POST['username'])."'";
		$result = $conn->query($sql);

		if ($result->num_rows > 0) {
			echo '<div align="center">Username already taken.</div>';
		} else {
			$sql = "INSERT INTO users (first_name,last_name,dob,gender,mobile_no,email_id,username,password,adrs,city,country,zip,registered_time) VALUES ('".$conn->real_escape_string($_POST['Firstname'])."','".$conn->real_escape_string($_POST['Lastname'])."','".$conn->real_escape_string($_POST['dob'])."','".$conn->real_escape_string($_POST['gender'])."','".$conn->real_escape_string($_POST['mobileno'])."','".$conn->real_escape_string($_POST['emailid'])."','".$conn->real_escape_string($_POST['username'])."','".$conn->real_escape_string($_POST['pswd'])."','".$conn->real_escape_string($_POST['addr'])."','".$conn->real_escape_string($_POST['city'])."','".$conn->real_escape_string($_POST['country'])."','".$conn->real_escape_string($_POST['zip'])."','".date("Y-m-d H:i:s")."');";

			if ($conn->query($sql) === TRUE) {
			    echo '<div align="center">User Registered.</div>';
			    header("Refresh:1; url=Login.php");
			} else {
			    echo '<div align="center">Unable to register user.</div>';
			}
		}
		$conn->close();
	}
?>
<?php

$host="localhost"; // Host name
$username="root"; // Mysql username
$password=""; // Mysql password
$db_name="grocery_store"; // Database name
$tbl_name="users"; // Table name

// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect");
mysql_select_db("$db_name")or die("cannot select DB");

$q1 = "select *from $tbl_name";
$result1 = mysql_query($q1) or die(mysql_error());
?>-->

<form action="resetdone.php" method="post">
<h1 style="color:blue" align="center">Password Reset Form</h1>
 <table width="400" align="center" border="1" >
                        
                  						
						<tr>
						<td>
						<label for="dob"> <span style="color:red"> <sup>*</sup></span>Enter Your Date of Birth </label> 
						
						</td>
						<td>
						<input type="text" name="dob"  id="dob" pattern="\d{1,2}-\d{1,2}-\d{4}" placeholder="DD-MM-YYY" required validationMessage="Enter date of birth" /> 
						</td>
						</tr>		
						
						
						
                         <td>
                        <label for="emailid" class="required"><span style="color:red" ><sup>*</sup> </span>Enter Your Email Id</label>
						 
                		 </td>
						 <td>
                        <input type="email" name="emailid" id="emailid" placeholder="Enter Email Id"  required validationMessage="Enter Email Id" />
                		 </td>
				         </tr>					
						
						    <td colspan="2" align="center"><b>Enter New Password</b></td>
  </tr>

						<tr>
    <td><label for="pswd" class="required">
						<span style="color:red" ><sup>*</sup> </span>Password</label>
						 </td>
						<td><input type="password" name="newpass" id="pswd" placeholder="Enter Password"  required validationMessage="Enter Password" /></td>
  </tr>
						<tr>
						<td colspan="8" align="center">
						<button class="btn btn-large btn-success" type="Submit" name="submit">Reset</button>
                        <button class="btn btn-large btn-warning" onclick="location.href='Login.php'" type="reset">Cancel</button>
						</td>
						</tr>
						</table>
						</form>
			<br>
<br>
<br>
<center>
<footer>
<b>All rights reserved.
 �  2017 Project @ SAU
Privacy policy</b>
</footer>
</center>	
</body>

 </html>
