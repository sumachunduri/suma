<?php
require_once('connection.php');
$userid=$_POST['username'];
$password=$_POST['password'];
$userid = stripslashes($userid);
$password = stripslashes($password);
$userid = mysql_real_escape_string($userid);
$password = mysql_real_escape_string($password);

 
   $sql="select username,password,type from users where username='$userid' and password='$password'";
    
    $rs=mysql_query($sql);
$l=0;

    while($myrow=mysql_fetch_array($rs))
     {
 
	  
        $u=$myrow[0]; $p=$myrow[1];$type=$myrow[2];

   		
      }


      

	    if($userid !='' && $password==$p && $password !='' && $type=="admin")
	    {
	     session_start();
    	$_SESSION['uname'] = $userid;
	    session_register("userid");
		session_register("password");
       	header('Location:admindashboard.php');
       	}
       	
	    else if($userid !='' && $password==$p && $password!='' && $type="user")
	    {
	    session_start();
    	$_SESSION['uname'] = $userid;
	    session_register("userid");
		session_register("password");
       	header('Location:index.php');
       	}
            else if($userid !='' && $password==$p && $password!='' && $type="store")
	    {
	    session_start();
    	$_SESSION['uname'] = $userid;
	    session_register("userid");
		session_register("password");
       	header('Location:storedashboard.php');
       	}


	else
	header('Location:index1.php');
	   		  ?>

