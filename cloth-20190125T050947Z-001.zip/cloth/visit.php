<html>
<title>Added to cart</title>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

body {
    background-color: white;
}
.button {
    background-color:teal;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	
	
}
 
</style>
</head>
<body align="center" style="background-color:white">
<?php include "menu.php"; ?>
<?php include "connect.php"; ?>



<center><form action="#" method=POST>

Date:<input type=date name=vdate><br><br>
Timing:<input type=time name=vtime><br><br>
<input type=submit value=VISIT></center>



<br><br><br><br><br><br><br><br><br><br>
</form>

<form name=xx action=# method=POST>
<?php

session_start();

$u=$_SESSION['user'];

	require 'connect.php';

	$vdate=$_POST['vdate'];
$id=$_GET['id'];

$vtime=$_POST['vtime'];

$sql = "SELECT * FROM products where id='$id'";
		$result = $conn->query($sql);
			
		if ($result->num_rows > 0) {
			$pro=0;
			while ($row=$result->fetch_assoc()) {
				
			$d= $row['name'];
				

								
				}
				}
				
			
$sql = "INSERT INTO visit VALUES ('$id','$first_name','$mobile_no','$vdate','$vtime','$u')";
		$conn->query($sql);

?>
</body>
</html>
</form>