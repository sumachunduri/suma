<?php
    $body="";
    if (isset($_GET['id'])) {
        require 'connect.php';
        $sql = "SELECT * FROM gadget_products where id=".$conn->real_escape_string($_GET['id']);
		$result = $conn->query($sql);
       
		
		//echo "<input type='text' name='iname' value='. $total'>";

        if ($result->num_rows > 0) {
            $row=$result->fetch_assoc();
            $body='  <h3 align="center">'.$row['name'].'</h3>
			<h3 align="center">Price:INR<s> '.$row['price'].'</s></h3>
			<h3 align="center">Offer Price:INR '.$row['offer'].'</h3>
			        <center><img style="width:20%;height:60%;" src="img/'.$row['image'].'"><img style="width:20%;height:60%;" src="img/'.$row['image1'].'"><img style="width:20%;height:60%;" src="img/'.$row['image2'].'"></center>';
			
            $desc=explode("\n", $row['description']);
			
            foreach ($desc as $p) {
                $body.='<p>'.$p.'</p>';
            }         
           $body.='<center>  <a href="CartSuccess.php?id='.$_GET['id'].'" class="button">ADD TO CART</a>
                      <a href="Products.php" class="button">< BACK TO PRODUCTS</a>
                        <a href="visit.php?id='.$_GET['id'].'" class="button">VISIT</a>
			<a href="blockit.php?id='.$_GET['id'].'" class="button">BLOCK IT</a></center>';
        } else {
            $body='Product not found.';
        }
        $conn->close();
    }
    else
        header("Location: Products.php");
        echo "<input type=hidden name=id value='$id'>";

		
?>
<html>
<title>Product details</title>
<head>
<style>

body {
    background-color: white;
}
.button {
    background-color:teal;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	
	
}
</style>
</head>
<body>
<?php
	include "menu.php"; 
	echo $body;
?>
<form name="indexform" method="POST" action="PaymentOption.php">

<input type=hidden name=id value=<?php echo $id ?>>
	
	<?php
 include("condb.php");
 //if (isset($_GET['id']))
 $id = $_GET['id'];
 $sql1 = "select name,price from gadget_products where id=$id";
//$result1 = $conn->query($sql1);

$result1=mysql_query($sql1) or die(mysql_error());
mysql_error();
while( $row1 = mysql_fetch_array($result1))
{
	//echo <input type='text' name='iname' value=$row1['name']>; 
?>
		<input type="hidden" name="iname" value="<?php echo $row1['name']; ?>">
		<input type="hidden" name="pprice" value="<?php echo $row1['price']; ?>">
		
<?php } 
echo "<input type=hidden name=id value='$id'>";

?>




</form>
</body>
</html>