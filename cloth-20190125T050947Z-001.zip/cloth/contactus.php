<html>
<title>Contact</title>
<head>
<style>

body {
    background-color: white;
}
.button {
    background-color:teal;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	
	
}
 
</style>
</head>

<?php include "menu.php"; ?>
<center>
<h1>CONTACT US</h1>
<p>B.SATISH</p>
<p>Correspondence</p>
<p>Mobile: +91-1234567890</p>
<p>Email:info@glocery.com</p>
<p>Skype : Checkit</p>
</center>
        
          
<br>
<br>
<br>
<br>
<br>


<center>
<footer>
<b>All rights reserved.
 �  2017 Project @ SAU
Privacy policy</b>
</footer>
</center>
</body>
</html>

