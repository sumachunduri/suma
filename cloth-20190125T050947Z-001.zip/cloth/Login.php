<?php
session_start();
if (isset($_SESSION['cus_log']))
	header("Location: index.php");
if (isset($_POST['submit']))
{
	require 'connect.php';
	
	$sql = "SELECT id,first_name FROM users where username='".$conn->real_escape_string($_POST['username'])."' and password='".$conn->real_escape_string($_POST['pwd'])."'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		$userid=$result->fetch_assoc();
		$sql = "INSERT INTO user_logins (user_id,in_time,ip) VALUES ('".$conn->real_escape_string($userid['id'])."','".date("Y-m-d H:i:s")."','".$_SERVER['REMOTE_ADDR']."');";
		$conn->query($sql);
		
		$_SESSION['cus_log']=$conn->insert_id;
		$_SESSION['user']=$userid['first_name'];

		header("Location: index.php");
	} 

 else {
		echo '<div align="center">Username and Password are not matched.</div>';
	}
	$conn->close();
}
?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Login</title>
<style>
label {
        width:100px;
         clear:left;
         text-align:left;
        padding-right:10px;
}
input, label
{
    float:left;
}

/* Full-width input fields */
input[type=text], input[type=password] {
    width: 100%;
    padding: 12px 20px;
    margin: 8px 0;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

/* Set a style for all buttons */
button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
}

button:hover {
    opacity: 0.8;
}

/* Extra styles for the cancel button */
.cancelbtn {
    width: auto;
    padding: 10px 18px;
    background-color: #f44336;
}

/* Center the image and position the close button */
.imgcontainer {
    text-align: center;
    margin: 12px 0 6px 0;
    position: relative;
}

img.avatar {
    width: 40%;
    border-radius: 50%;
}

.container {
    padding: 16px;
}

span.psw {
    float: right;
    padding-top: 16px;
}

/* The Close Button (x) */
.close {
    position: absolute;
    right: 25px;
    top: 0;
    color: #000;
    font-size: 35px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: red;
    cursor: pointer;
}
</style>

</head>
<body align="center" style="background-color:white">
<h1 align="center"><font color="blue">Login</font></h1>
<form action="Login.php" method="post">

<div class="container">
      <center><img src="img/img_avatar2.png" alt="Avatar" class="avatar" style="width:15%"><br><br></center>
      <label for="username"><b>Username</b></label>
      <input type="text" id="username" placeholder="Enter Username" name="username" required validationMessage="Enter valid Username" />

      <label for="Password"><b>Password</b></label> 
      <input type="password" id="pwd" placeholder="Enter Password" name="pwd" required validationMessage="Enter Password" />
        
      <button name="submit" type="Submit" class="btn btn-large btn-success">Login</button>

      <button type="reset" class="btn btn-large btn-warning" onclick="location.href='index.php'" >Cancel</button>
      
    </div>

<center><a href="Register.php">New User Register Here</a>  ||  <a href="reset.php">Reset Password</a></center>
</form>
</body>

<br>
<br>
<br>
<center>
<footer>
<b>All rights reserved.
 �  2017 Project @ SAU
Privacy policy</b>
</footer>
</center>

</html>