<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Reset Password</title>
</head>
<body align="center" style="background-color:white">
<?php

$host="localhost"; // Host name
$username="root"; // Mysql username
$password=""; // Mysql password
$db_name="grocery_store"; // Database name
$tbl_name="users"; // Table name

// Connect to server and select database.
mysql_connect("$host", "$username", "$password")or die("cannot connect");
mysql_select_db("$db_name")or die("cannot select DB");


$a1=$_POST['dob'];
$a2=$_POST['emailid'];
$a3=$_POST['newpass'];

//$i=0;

$sql="SELECT * FROM $tbl_name where dob='$a1' and email_id='$a2'";
$rd=mysql_query($sql);
$num_rows = mysql_num_rows($rd);


//$result1=mysql_query($sql1) or die(mysql_error());
//mysql_error();
//while($myrow=mysql_fetch_row($rd))
//{
//$pass=$myrow[0];
//$i++;
//}

//$pass="welcome";

//if($i>0)
//{
	if ($num_rows!=0)
	{
$sql="update $tbl_name set password='$a3' where email_id='$a2'";
$rd=mysql_query($sql);
echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
echo "<center><font size=5 color=green> password is sucessfully Reset to <font color=red> $a3</font>";
echo "<br>";
echo "<br>";
echo "<a href='Login.php'>Please Login</a>";
//}
}

else
{
echo "<center><font size=5 color=red>Your Entered Details Mismatch </font>";

}
 
?>
<br>
<br>
<br>
<center>
<footer>
<b>All rights reserved.
 �  2017 Project @ SAU
Privacy policy</b>
</footer>
</center>		
</body>
 </html>
