<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Payment</title>
<style>

body {
    background-color: #CAD8DC;
}
.button {
    background-color:teal;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	
	
}
 
</style>
</head>



<body style="background-color:white" >
<?php
include "menu.php"; 
		require 'connect.php';

$id=$_GET['id'];

if($id=='')
{
$id=$_POST['id'];
}

?>
<form name=xx action="CardDetails.php" method="post">

<input type="hidden" name="id" value=<?php echo $id ?>>
<h1 style="color:blue" align="center">Select Payment Mode</h1>
 <table align="center">
                       <tr>
					   <td align="center">
						<label for="gen" class="required"></label><br><font size=5>
						<input type="radio" name="card" value="DebitCard" checked="checked"/><label>Debit Card</label>
					    <input type="radio" name="card" value="CreditCard"/><label>Credit Card</label>
						<input type="radio" name="card" value="RupayCard"/><label>Rupay Card</label></font>
						</td>
						</tr>	</table>
						
						<br><br>
<table align="center">	
						<tr>
						<td colspan="8" align="center">

						<button class="button" type="Submit">Pay Now</button>
                        <button class="button" onclick="location.href='Products.php'" type="reset">Cancel</button>
						</td>
						</tr>
						</table>
						</form>
						
</body>
</head>
 </html>
