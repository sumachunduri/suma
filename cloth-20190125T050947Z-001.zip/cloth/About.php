<html>
<title>About</title>
<head>
<style>

body {
    background-color: white;
}
.button {
    background-color:teal;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	
	
}

 body>
</style>
</head>
<body>


<?php include "menu.php"; ?>

 <h3 align="center"> ABOUT US</h3>
<p>Electronic commerce, commonly written as e-commerce or eCommerce, is the trading or facilitation of trading in 
 products or services using computer networks, such as the Internet or online social networks.Electronic commerce 
 draws on technologies such as mobile commerce, electronic funds transfer, supply chain management, 
 Internet marketing, online transaction processing, electronic data interchange (EDI), inventory management systems,
 and automated data collection systems. Modern electronic commerce typically uses the World Wide Web for at least 
 one part of the transaction's life cycle although it may also use other technologies such as e-mail.</p>
 
 <h3><b>History of e-commerce</b></h3>
<p>The beginnings of e-commerce can be traced to the 1960s, when businesses started using Electronic Data Interchange
 (EDI) to share business documents with other companies. In 1979, the American National Standards Institute developed
 ASC X12 as a universal standard for businesses to share documents through electronic networks. After the number of 
 individual users sharing electronic documents with each other grew in the 1980s, in the 1990s the rise of eBay and 
 Amazon revolutionized the e-commerce industry. Consumers can now purchase endless amounts of items online, both 
 from typical brick and mortar stores with e-commerce capabilities and one another.</p>

 <br> </br>
 <br> </br>
 <br> </br>



<h3><b>E-commerce businesses may employ some or all of the following:</b></h3>
<li>Online shopping web sites for retail sales direct to consumers</li>
<li>Providing or participating in online marketplaces, which process third-party business-to-consumer or consumer-to-consumer sales</li>
<li>Business-to-business buying and selling</li>
<li>Gathering and using demographic data through web contacts and social media</li>
<li>Business-to-business electronic data interchange</li>
<li>Marketing to prospective and established customers by e-mail or fax (for example, with newsletters)</li>
<li>Engaging in pretail for launching new products and services</li>
<li>Online financial exchanges for currency exchanges or trading purposes</li></p>

 





<br><br><br></br></br></br>

<p>E-commerce (electronic commerce or EC) is the buying and selling of goods and services, or the transmitting of 
funds or data, over an electronic network, primarily the internet. These business transactions occur either as 
business-to-business, business-to-consumer, consumer-to-consumer or consumer-to-business. The terms e-commerce and 
e-business are often used interchangeably. The term e-tail is also sometimes used in reference to transactional 
processes for online shopping.</p>

<h3><b>E-commerce applications</b></h3>
<p>E-commerce is conducted using a variety of applications, such as email, online catalogs and shopping carts, EDI, File Transfer Protocol, and web services. This includes business-to-business activities and outreach such as using email for unsolicited ads (usually viewed as spam) to consumers and other business prospects, as well as to send out e-newsletters to subscribers. More companies now try to entice consumers directly online, using tools such as digital coupons, social media marketing and targeted advertisements.</p>
<center>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="footer.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<footer>
<div class="foot" >
<div> 
<div class="foot1">All rights reserved. � Designed and Developed at VRSEC </div>
<a href="#" class="fa fa-facebook"></a>
<a href="#" class="fa fa-twitter"></a>
<a href="#" class="fa fa-google"></a>
<a href="#" class="fa fa-linkedin"></a>
<a href="#" class="fa fa-youtube"></a>
<a href="#" class="fa fa-instagram"></a>
</div>
</div>
</footer>
</body>
</html>

