<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Card Details</title>
<style>


body {
    background-color: #CAD8DC;
}
.button {
    background-color:teal;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	
	
}
 
</style>


<font >

<body align="center" style="background-color:white">
<form name=xx action=cc.php method=post>
<?php
	include "menu.php";
	session_start();

$u=$_SESSION['user'];

		require 'connect.php';

		
$cardno=$_POST['cardno'];
$edate=$_POST['edate'];
$cvv=$_POST['CVV'];
$zip=$_POST['zip'];

$id=$_POST['id'];



$sql="SELECT * FROM products where id='$id'";
		$result = $conn->query($sql);
			
		if ($result->num_rows > 0) {
			$pro=0;
			while ($row=$result->fetch_assoc()) {
				
			$d= $row['name'];
				
$price=$row['price'];
$name=$row['name'];
$desc=$row['description'];
$img=$row['image'];
								
				}
				}

$date=date('Y-m-d');
			
$sql = "INSERT INTO payment VALUES ('$id','$price','$name','$desc','$img','$cardno','$edate','$cvv','$zip','$date','$u')";
		$conn->query($sql);


$sql="delete from cart where pid='$id' and user='$u'";
		$conn->query($sql);

?>

	<h1 align="center">Payment Successfully Done</h1>
<h2 align="center">Please verify your order history</h2>
					
</body>
</head>
 </html>
