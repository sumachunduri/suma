<html>
<title>Added to cart</title>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

body {
    background-color: white;
}
.button {
    background-color:teal;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	
	
}
 
</style>
</head>
<body align="center" style="background-color:white">
<?php include "menu.php"; ?>
<?php include "connect.php"; ?>

<br><br><br><br><br><br><br><br><br><br>
<?php

session_start();

$u=$_SESSION['user'];

	require 'connect.php';

	$id=$_GET['id'];



$sql = "SELECT * FROM products where id='$id'";
		$result = $conn->query($sql);
			
		if ($result->num_rows > 0) {
			$pro=0;
			while ($row=$result->fetch_assoc()) {
				
			$d= $row['name'];
				
$price=$row['price'];
$name=$row['name'];
$desc=$row['description'];
$img=$row['image'];
								
				}
				}
				
			
$sql = "INSERT INTO blockit VALUES ('$id','$price','$name','$img','$desc','$u')";
		$conn->query($sql);

?>
</body>
</html>


<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Card Details</title>
<style>


body {
    background-color: white;
}
.button {
    background-color:teal;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	
	
}
 
</style>




<body style="background-color:#4CAF50" >
 
<?php
$id=$_POST['id'];


	require 'connect.php';




$sql = "SELECT * FROM products where id='$id'";
		$result = $conn->query($sql);
			
		if ($result->num_rows > 0) {
			$pro=0;
			while ($row=$result->fetch_assoc()) {
				
			$d= $row['name'];
				
$price=$row['price'];
$name=$row['name'];
$desc=$row['description'];
$img=$row['image'];
								
				}
				}

?>
<form action="payment.php" method="POST">
<input type="hidden" name="id" value="<?php echo $id ?>">
<input type="hidden" name="user" value="<?php echo $a2 ?>">
<input type="hidden" name="dd" value="<?php echo $a3 ?>">

<h1 style="color:blue" align="center">Payment Form</h1>
 <table align="center" border="1">
                        <tr>
                        <td>
                        <label for="cardno" class="required"><span style="color:red" ><sup>*</sup> </span>Enter Card No</label>
						</td>
						<td>
						<input type="text" name="cardno" id="cardno" pattern="\d{16}" placeholder="Enter 16 Digit cardno"  required validationMessage="Enter cardno" size="20" /> 
                		 </td>
						 </tr>
						 <tr>
						 <td>
                        <label for="Expirationdate" class="required"> <span style="color:red"> <sup>*</sup></span> Expiration Date </label>
						</td>
						<td>
						<input type="text" name="edate" id="Expirationdate" class="form-control" placeholder="Enter MM/YYYY" required validationMessage="enter Expirationdate" size="20" />
                		 </td>
				         </tr>
  
                        <tr>
                        <td>
                        <label for="Firstname" class="CVV"><span style="color:red"> <sup>*</sup> </span>CVV</label>
						</td>
						<td>
						<input type="text" name="CVV" id="CVV"  pattern="\d{3}" placeholder="Enter 3 digit CVV"  required validationMessage="Enter valid CVV" size="20" /> 
                		 </td>
						 </tr>
						 <tr>
				        <td>
						<label for="zip" class="required"><span style="color:red" ><sup>*</sup> </span>Zip Code</label>
                       </td>
						<td>
						<input type="text" name="zip" id="zip" pattern="\d{6}" placeholder="Enter zip" required validationMessage="enter zip" size="20"/> 
		        		</td>
						</tr>
						 <tr>
				        <td>
						<label for="zip" class="required"><span style="color:red" ><sup>*</sup> </span>Amount $</label>
                       </td>
						<td>
						<input type="text" name="zip" value="<?php echo $price ?>" id="zip" placeholder="" required validationMessage="enter zip"/> 
		        		</td>
						</tr>
						
						
						
						
						<tr>
						<td colspan="8" align="center">
						<button class="btn btn-large btn-success" type="Submit">Pay Now</button>
						<button class="btn btn-large btn-warning" onclick="location.href='payment.php'" type="reset">Cancel</button>
                   		</td>
						</tr>
						</table>
						</form>
						
</body>
</head>
 </html>
