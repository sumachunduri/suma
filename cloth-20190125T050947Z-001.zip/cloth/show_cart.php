<!DOCTYPE html>
<html lang="en-us">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Your cart</title>
<style>

body {
    background-color: #CAD8DC;
}
.button {
    background-color:teal;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	
	
}
 
</style>
</head>
<div>

</div>
<body align="center" style="background-color:white">
<form name=xx action=paymentOption.php method=post>
<?php
	include "menu.php";
	echo "<h1 align='center' style='color:blue'>Your cart</h1>";
	session_start();

$u=$_SESSION['user'];

		require 'connect.php';

    
		$sql = "SELECT * FROM cart where user='$u'";
		$result = $conn->query($sql);



		if ($result->num_rows > 0) {
			echo "<table align='center' cellspacing='20px'><tr>";
			$pro=0;
			while ($row=$result->fetch_assoc()) {
			
$img=$row['img'];
$sid=$row['pid'];

				echo"<td><a href='paymentOption.php?id=$sid'><img src='img/$img' height='300px' width='300px'/></td>
				<tr><td><input type='text' name='s1' value=".$row['name']." 
				readonly> || <input type='text' name='s2' value=$".$row['price']."
				readonly>
				</td></tr>";
				//echo $row['name'];
				//$d= $row['name'];
				//echo $d;
				//echo "<input typ='text' name=d value='$d'>";
					
				$pro++;
				if ($pro==3){
					echo "</tr><tr>";
					$pro=0;
					
				}
			}
				echo "</tr></table>";
				
		} 
		$conn->close();
	
?>


    


<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<center>
<footer>
<b>All rights reserved.
 �  2017 Project @ SAU
Privacy policy</b>
</footer>
</center>
</body>
<html>