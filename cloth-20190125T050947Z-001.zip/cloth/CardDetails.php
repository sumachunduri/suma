<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Card Details</title>
<style>
input[type=text], input[type=password] {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    display: inline-block;
    border: none;
    background: #f1f1f1;
}

/* Add a background color when the inputs get focus */
input[type=text]:focus, input[type=password]:focus {
    background-color: #ddd;
    outline: none;
}

button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 100%;
    opacity: 0.9;
}

button:hover {
    opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
    padding: 14px 20px;
    background-color:  #f44336;
    float: left;
    width: 100%;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn1{
  float: left;
  width: 100%;
}
.cancelbtn1 {
    padding: 14px 20px;
    background-color: #4CAF50;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn1{
  float: left;
  width: 100%;
}
/* Add padding to container elements */
.container {
    padding: 16px;
}

hr {
    border: 1px solid #f1f1f1;
    margin-bottom: 25px;
}
 
/* The Close Button (x) */
.close {
    position: absolute;
    right: 35px;
    top: 15px;
    font-size: 40px;
    font-weight: bold;
    color: #f1f1f1;
}

.close:hover,
.close:focus {
    color: #f44336;
    cursor: pointer;
}

/* Clear floats */
.clearfix::after {
    content: "";
    clear: both;
    display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
    .cancelbtn{
       width: 100%;
    }
}


body {
    background-color: white;
}
.button {
    background-color:teal;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	
	
}
 
</style>




<body style="background-color:white" >
<?php include "menu.php"; 
$id=$_POST['id'];


	require 'connect.php';




$sql = "SELECT * FROM products where id='$id'";
		$result = $conn->query($sql);
			
		if ($result->num_rows > 0) {
			$pro=0;
			while ($row=$result->fetch_assoc()) {
				
			$d= $row['name'];
				
$price=$row['price'];
$name=$row['name'];
$desc=$row['description'];
$img=$row['image'];
								
				}
				}

?>
<form action="payment.php" method="POST">
<input type="hidden" name="id" value="<?php echo $id ?>">
<input type="hidden" name="user" value="<?php echo $a2 ?>">
<input type="hidden" name="dd" value="<?php echo $a3 ?>">

<h1 style="color:blue" align="center">Payment Form</h1><center>
 <table align="center" border="0" width="50%">
                        <tr>
                        <td>
                        <label for="cardno" class="required"><span style="color:red" ><sup>*</sup> </span>Enter Card No :</label>
						</td>
						<td>
						<input type="text" name="cardno" id="cardno" pattern="\d{16}" placeholder="Enter 16 Digit cardno"  required validationMessage="Enter cardno" size="20" /> 
                		 </td>
						 </tr>
						 <tr>
						 <td>
                        <label for="Expirationdate" class="required"> <span style="color:red"> <sup>*</sup></span> Expiration Date :</label>
						</td>
						<td>
						<input type="text" name="edate" id="Expirationdate" class="form-control" placeholder="Enter MM/YYYY" required validationMessage="enter Expirationdate" size="20" />
                		 </td>
				         </tr>
  
                        <tr>
                        <td>
                        <label for="Firstname" class="CVV"><span style="color:red"> <sup>*</sup> </span>CVV :</label>
						</td>
						<td>
						<input type="text" name="CVV" id="CVV"  pattern="\d{3}" placeholder="Enter 3 digit CVV"  required validationMessage="Enter valid CVV" size="20" /> 
                		 </td>
						 </tr>
						 <tr>
				        <td>
						<label for="zip" class="required"><span style="color:red" ><sup>*</sup> </span>Zip Code :</label>
                       </td>
						<td>
						<input type="text" name="zip" id="zip" pattern="\d{6}" placeholder="Enter zip" required validationMessage="enter zip" size="20"/> 
		        		</td>
						</tr>
						 <tr>
				        <td>
						<label for="zip" class="required"><span style="color:red" ><sup>*</sup> </span>Amount :</label>
                       </td>
						<td>
						<input type="text" name="zip" value="<?php echo $price ?>" id="zip" placeholder="" required validationMessage="enter zip"/> 
		        		</td>
						</tr>
						
						
						
						
						<tr>
						<td colspan="8" align="center">
						<button class="cancelbtn1" type="Submit"><font size=3>Pay Now</font></button></td></tr><tr><tr></tr><tr></tr><tr></tr><tr></tr><tr></tr><tr><td colspan="8" align="center">
						<button class="cancelbtn" onclick="location.href='payment.php'" type="reset"><font size=3>Cancel</font></button>
                   		</td>
						</tr>
						</table></center>
						</form>
						
</body>
</head>
 </html>
