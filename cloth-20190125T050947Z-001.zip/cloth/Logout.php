<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">
<title>Logout</title>
<style>
button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 0;
    border: none;
    cursor: pointer;
    width: 50%;
    opacity: 0.9;
}

button:hover {
    opacity:1;
}
label {
    width:110px;
    clear:left;
    text-align:left;
    padding-right:10px;
}
input, label {
    float:left;
}
td{
    padding: 15px;
}
</style>
</head>
<body align="center" style="background-color:white">
<?php
	require 'connect.php';

	session_start();

	$sql = "update user_logins set out_time='".date("Y-m-d H:i:s")."' where id='".$conn->real_escape_string($_SESSION['cus_log'])."');";
	$conn->query($sql);
	
	unset($_SESSION['cus_log']);
	unset($_SESSION['cart']);
	session_destroy();

	$conn->close();
?>
<center>
<h2>Logged out successfull
<br><br><br>
<a href="index.php"><button type="submit" class="button" name="home"><font size="4">Home</font></button></a>
 <a href="login.php"><button type="submit" class="button" name="login"><font size="4">Login</font></button></a></center>
<br>
<br>
<br>
<center>
<footer>
<b>All rights reserved.
 �  2017 Project @ SAU
Privacy policy</b>
</footer>
</center>
</body>

</html>