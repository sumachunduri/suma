<html>
<title>Added to cart</title>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

body {
    background-color: white;
}
.button {
    background-color:teal;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	
	
}
 
</style>
</head>
<body align="center" style="background-color:white">
<?php include "menu.php"; ?>
<?php include "connect.php"; ?>

<br><br><br><br><br>
<?php

session_start();
echo  $_SESSION['user'];
$u=$_SESSION['user'];

	require 'connect.php';

	$id=$_GET['id'];



$sql = "SELECT * FROM products where id='$id'";
		$result = $conn->query($sql);
			
		if ($result->num_rows > 0) {
			$pro=0;
			while ($row=$result->fetch_assoc()) {
				
			$d= $row['name'];
				
$price=$row['price'];
$name=$row['name'];
$desc=$row['description'];
$img=$row['image'];
								
				}
				}
				
			
$sql = "INSERT INTO cart VALUES ('$id','$price','$name','$desc','$img','$u')";
		$conn->query($sql);
echo "<h3>Successfully added to cart</h3>";

?>
</body>
</html>