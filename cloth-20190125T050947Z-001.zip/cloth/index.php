<!DOCTYPE html>
<html lang="en-us">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Home</title>
<style>
.button {
    background-color:teal;
	
    border: none;
    color: white;
    padding: 10px 30px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 0px;
    cursor: pointer;
}

nav a {
display:block;
text-align:center;
width:100px; /* fixed width */
text-decoration:none; 
 <!--background-color:red;-->
}
.dropbtn {
    background-color: ;
    color: white;
    padding: 15px 32px;
    font-size: 16px;
    display: inline-block;
    margin: 4px 2px;
    border: none;
    cursor: pointer;
}

.dropdown {
    position: relative;
   display: inline-block;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color:green;
    min-width: 160px;
    box-shadow: 0px 0px 8px 0px rgba(0,0,0,0);
}

.dropdown-content a {
    color: white;
    padding: 10px 30px;
    text-decoration: none;
    display: block;
}

.dropdown-content a:hover {background-color:#F08080}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown:hover .dropbtn {
    background-color: #3e8e41;
				
}
mySlides {display:none;}
.ws12{
font-size: 16px;
}
.scroller-item h2 {
    position: absolute;
    width: 100%;
    bottom: 1px;
    padding: 0 20px;
    font-size: 17px;
    font-weight: 700;
    color: white;
    text-shadow: 0 0 5px #000;
}


</style>
</head>
<body align="center" style="background-color:white">

<?php include "menu.php"; ?>

<div align="center">
 <img class="mySlides" src="Img/shopping.jpg" width="100%" height="400px" style="margin: 10px"/>
    <img class="mySlides" src="Img/Minors.JPG" width="100%" height="400px" style="margin: 10px"/>
   <img class="mySlides" src="Img/1.jpg" width="100%" height="400px" style="margin: 10px"/>
   <img class="mySlides" src="Img/My Post (2).jpg" width="100%" height="400px" style="margin: 10px"/>
   <img class="mySlides" src="Img/My Post (11).jpg" width="100%" height="400px" style="margin: 10px"/>
  <img class="mySlides" src="Img/My Post (12).jpg" width="100%" height="400px" style="margin: 10px"/>
</div>

<script type="text/javascript">
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}
    x[myIndex-1].style.display = "block";
    setTimeout(carousel, 2000); // Change image every 2 seconds
}
</script>


<!DOCTYPE html>
<html>
<head> <title> visit</title>
<link rel="stylesheet" href="buttons.css">
</head>
<body>
	<header>
		<div class="buttons"><font size=5> CLOTHING</font></div>
	</header><br /><br />
	
</body>
</html>
<!--<div class="scroller-item"class="scroller-item">-->
<!--<h2> Commputer Sceince Engineering</h2>-->
<center>
 <a href="products.php"><img src="img/shirt1.jpg" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="products.php"><img src="img/shirt2.jpg" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="products.php"><img src="img/shirt3.jpg" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="products.php"><img src="img/womencloth1.jpg" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="products.php"><img src="img/womencloth2.jpg" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="products.php"><img src="img/womencloth3.jpg" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 
</center>
</div><br><br>

<!DOCTYPE html>
<html>
<head> <title> visit</title>
<link rel="stylesheet" href="buttons.css">
</head>
<body>
	<header>
		<div class="buttons"> <font size=5>FOOD</font></div>
	</header><br /><br />
	
</body>
</html>
<!--<div class="scroller-item"class="scroller-item">-->
<!--<h2> Commputer Sceince Engineering</h2>-->
<center>
 <a href="food.php"><img src="img/cupnoodles.jpg" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="food.php"><img src="img/friedrice.jpg" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="food.php"><img src="img/kfc.jpg" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="food.php"><img src="img/manchowsoup.jpg" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
  <a href="food.php"><img src="img/rolls.jpg" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="food.php"><img src="img/prawns.jpg" width="200px" height="150px"/></a>
</center>
</div><br><br>

<!DOCTYPE html>
<html>
<head> <title> visit</title>
<link rel="stylesheet" href="buttons.css">
</head>
<body>
	<header>
		<div class="buttons"> <font size=5>GADGETS</font></div>
	</header><br /><br />
	
</body>
</html>
<!--<div class="scroller-item"class="scroller-item">-->
<!--<h2> Commputer Sceince Engineering</h2>-->
<center>
 <a href="gadgets.php"><img src="img/best_4.png" width="150px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="gadgets.php"><img src="img/best_6.png" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="gadgets.php"><img src="img/featured_7.png" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="gadgets.php"><img src="img/new_2.jpg" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="gadgets.php"><img src="img/102.jpg" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="gadgets.php"><img src="img/honour7x.jpg" width="200px" height="150px"/></a>
 
</center>
</div>

<!DOCTYPE html>
<html>
<head> <title> visit</title>
<link rel="stylesheet" href="buttons.css">
</head>
<body>
	<header>
		<div class="buttons"><font size=5>SHOPS</font></div>
	</header><br /><br />
	
</body>
</html>
<!--<div class="scroller-item"class="scroller-item">-->
<!--<h2> Commputer Sceince Engineering</h2>-->
<center>
 <a href="shop.php"><img src="img/crossroads.jpg" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="shop.php"><img src="img/rrdaurbar.jpg" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="shop.php"><img src="img/temptations.jpg" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="shop.php"><img src="img/barbeque.jpg" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="shop.php"><img src="img/sweetmagic.jpg" width="200px" height="150px"/></a>&nbsp;&nbsp;&nbsp;&nbsp;
 <a href="shop.php"><img src="img/sevendays.jpg" width="200px" height="150px"/></a>
 
</center>
</div>



<br></br>




</body>
</html>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="footer.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<footer>
<div class="foot" >
<div> 
<div class="foot1">All rights reserved. � Designed and Developed at VRSEC </div>
<a href="#" class="fa fa-facebook"></a>
<a href="#" class="fa fa-twitter"></a>
<a href="#" class="fa fa-google"></a>
<a href="#" class="fa fa-linkedin"></a>
<a href="#" class="fa fa-youtube"></a>
<a href="#" class="fa fa-instagram"></a>
</div>
</div>
</footer>
</body>
</html>

