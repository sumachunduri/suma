<!DOCTYPE html>
<html lang="en-us">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Products</title>
<style>

body {
    background-color: #CAD8DC;
}
.button {
    background-color:teal;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
	
	
}
 
</style>
</head>
<div>
</div>
<body align="center" style="background-color:white">

<?php
	include "menu.php";
	echo "<h1 align='center' style='color:blue'>GADGETS</h1>";
	require 'connect.php';
	
	$sql = "SELECT * FROM gadget_products";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		echo "<table align='center' cellspacing='100px'><tr>";
		$pro=0;
		while ($row=$result->fetch_assoc()) {
			echo "<td><a href='gadget_details.php?id=".$row['id']."'><img src='img/".$row['image']."' height='300px' width='300px'/><br><center>".$row['name']." <br>INR".$row['price']."</center></a></td>";
			$pro++;
			if ($pro==3){
				echo "</tr><tr>";
				$pro=0;
			}
		}
			echo "</tr></table>";
	} else {
		echo 'Sorry, we have no products to show.';
	}
	$conn->close();
?>
<center>
<footer>
<b>All rights reserved.
 �  2017 Project @ SAU
Privacy policy</b>
</footer>
</center>
</body>
<html>