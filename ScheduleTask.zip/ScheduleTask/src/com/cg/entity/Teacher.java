package com.cg.entity;

import java.io.Serializable;
import java.sql.Date;






import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;


@Entity
@Table(name="teacher_details")
@NamedQueries(@NamedQuery(name="getAllPlans",query="SELECT e FROM Teacher e"))
public class Teacher implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	@Id
@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="id_seq")
@SequenceGenerator(name="id_seq", sequenceName="id_seq")
	@Column(name="teacher_id")
	public Integer teacherId;
	@NotBlank(message="Please enter data")
	@Column(name="teacher_name")
	public String teacherName;


	@Column(name="teacher_date")
	public Date  teacherDate;
	@NotBlank(message="Please enter data")
	@Column(name="teacher_expert")
	public String teacherExpert;
	@NotBlank(message="Please enter data")
	@Column(name="teacher_period")
	public String teacherPeriod;
	@NotBlank(message="Please enter data")
	@Column(name="teacher_comments")
	public String teacherComments;
	@NotBlank(message="Please enter data")
	
@Pattern(regexp="[A-Za-z0-9]+@[A-Za-z0-9]+[.][A-Za-z]{2,4}",message="Please enter valid Email ID")
	@Column(name="teacher_mail")
public String teacherMail;
	public Integer getTeacherId() {
		return teacherId;
	}
	public void setTeacherId(Integer teacherId) {
		this.teacherId = teacherId;
	}
	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	public Date getTeacherDate() {
		return teacherDate;
	}
	public void setTeacherDate(Date teacherDate) {
		this.teacherDate = teacherDate;
	}
	public String getTeacherExpert() {
		return teacherExpert;
	}
	public void setTeacherExpert(String teacherExpert) {
		this.teacherExpert = teacherExpert;
	}
	public String getTeacherPeriod() {
		return teacherPeriod;
	}
	public void setTeacherPeriod(String teacherPeriod) {
		this.teacherPeriod = teacherPeriod;
	}
	public String getTeacherComments() {
		return teacherComments;
	}
	public void setTeacherComments(String teacherComments) {
		this.teacherComments = teacherComments;
	}
	public String getTeacherMail() {
		return teacherMail;
	}
	public void setTeacherMail(String teacherMail) {
		this.teacherMail = teacherMail;
	}
	
	

}
