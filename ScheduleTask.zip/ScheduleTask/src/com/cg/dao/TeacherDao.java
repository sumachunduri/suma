package com.cg.dao;

import java.util.List;

import com.cg.entity.Teacher;

public interface TeacherDao {

	Teacher save(Teacher teacher1);

	List<Teacher> retrieveall();

	Teacher retrieve(Integer id);

}
