package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;



import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entity.Teacher;



@Repository

public class TeacherDaoImpl implements TeacherDao{
 
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Teacher save(Teacher teacher1) {
		// TODO Auto-generated method stub
		entityManager.persist(teacher1);
		entityManager.flush();	//required to reflect changes on database
		
		return teacher1;
	}

	@Override
	public List<Teacher> retrieveall() {
		// TODO Auto-generated method stub
		//TypedQuery<Teacher> query = entityManager.createQuery("SELECT e FROM Teacher e", Teacher.class);
		Query query=entityManager.createNamedQuery("getAllPlans");
		@SuppressWarnings("unchecked")
		List<Teacher> list= query.getResultList(); 
		 return list;
	}

	@Override
	public Teacher retrieve(Integer id) {
		// TODO Auto-generated method stub
		Teacher teacher = entityManager.find(Teacher.class, id);
		return teacher;
	}

}
