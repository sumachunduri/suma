package com.cg.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;









import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entity.Teacher;
import com.cg.sevice.TeacherService;


@Controller
public class ScheduleController {
	
	@Autowired TeacherService  teacherService;
@RequestMapping("/index")
public String getHomePage(){
	
	return "home";
}
@RequestMapping("/enter")
public String getPage(Model m){
	m.addAttribute("period",new String[]{"Maths","Physics","Chemistry","Bioloy","English"});
	java.sql.Date date=java.sql.Date.valueOf(LocalDate.now());
	m.addAttribute("date", date);
	m.addAttribute("teacher1", new Teacher());
	
	return "register";
}
@RequestMapping("/save")
public String saveTeacher(@ModelAttribute("teacher1") @Valid Teacher teacher1,BindingResult br, Model model){
	System.out.println("in save");
	String target="success";
	if(br.hasErrors()){
		target="register"; 
	}
	else{
		Teacher teacher =  teacherService.save(teacher1);
	model.addAttribute("message","Plan has been saved with id"+teacher.getTeacherId());
	target= "success";
	}
	return target;
}
@RequestMapping("/viewall")
public String retrieveAll(Model m)
{
	List<Teacher>tlist=new ArrayList<Teacher>();
	tlist= teacherService.retrieveall();
	m.addAttribute("list", tlist);
	return "retrieveall";
}
@RequestMapping("/view")
public String retrieve()
{
	return "retrievebyid";
}
@RequestMapping("/retrieve")
public String retrieveId(@RequestParam("id") Integer id,Model m)
{
	
		
	Teacher teacher2=teacherService.retrieve(id);
	if(teacher2==null){
		m.addAttribute("message", "NO DATA FOUND");
	}
	else{
		m.addAttribute("teacher2", teacher2);
		
		
	}
		return "retrievebyid";
	}
	
	
	
}
