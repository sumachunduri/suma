package com.cg.sevice;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.TeacherDao;
import com.cg.entity.Teacher;
@Service
@Transactional
public class TeacherServiceImpl  implements TeacherService{
	
	@Autowired TeacherDao teacherdao;

	@Override
	public Teacher save(Teacher teacher1) {
		// TODO Auto-generated method stub
		return teacherdao.save(teacher1);
	}

	@Override
	public List<Teacher> retrieveall() {
		// TODO Auto-generated method stub
		return teacherdao.retrieveall() ;
	}

	@Override
	public Teacher retrieve(Integer id) {
		// TODO Auto-generated method stub
		return teacherdao.retrieve(id) ;
	}

}
