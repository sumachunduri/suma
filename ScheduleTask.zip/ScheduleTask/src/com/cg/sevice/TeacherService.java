package com.cg.sevice;

import java.util.List;

import com.cg.entity.Teacher;

public interface TeacherService {

	Teacher save(Teacher teacher1);

	List<Teacher> retrieveall();

	Teacher retrieve(Integer id);

}
